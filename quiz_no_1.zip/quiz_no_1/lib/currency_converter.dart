import 'package:flutter/material.dart';

void main() {
  runApp(const CurrencyConverter());
}

class CurrencyConverter extends StatelessWidget {
  const CurrencyConverter({super.key});

  
  @override
  Widget build(BuildContext context) {
    const border = OutlineInputBorder(
      borderRadius: BorderRadius.all(Radius.circular(50)),
      borderSide: BorderSide(
        color: Color.fromARGB(222, 63, 76, 160),
        width: 2.0,
        style: BorderStyle.solid,
      )
    );
  
    return const MaterialApp(
       home: Scaffold(
        backgroundColor: Color.fromARGB(222, 197, 194, 211),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [Text("TABISH SHEIKH",style: TextStyle(color: Color.fromARGB(255, 8, 99, 174),fontSize: 30,fontWeight: FontWeight.bold ),),
             TextField(
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: "Please Enter Amount in rupee",
                  hintStyle: TextStyle(color: Colors.white),
                  prefixIcon: Icon(Icons.monetization_on,color: Colors.white,),
                  filled: true,
                  fillColor: Color.fromARGB(222, 63, 76, 160),
                  focusedBorder: border,
                  enabledBorder: border,
                ),
                keyboardType: TextInputType.numberWithOptions(decimal: true),
              ),
           ],
          ),
        ),
       )
    );
  }
}