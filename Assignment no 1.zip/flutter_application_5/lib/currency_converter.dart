import 'package:flutter/material.dart';
import 'text_field.dart';
import 'text.dart';
import 'text_button.dart';

void main() {
  runApp(const CurrencyConverter());
}

class CurrencyConverter extends StatelessWidget {
  const CurrencyConverter({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Scaffold(
        backgroundColor:  Color.fromARGB(205, 245, 234, 122),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
               CustomText(),
               CustomTextField(),
               CustomTextButton()
            ],
          ),
        ),
      ),
    );
  }
}
