import 'package:flutter/material.dart';

class CustomTextField extends StatelessWidget {
  const CustomTextField({super.key});

 @override
  Widget build(BuildContext context) {
    const border = OutlineInputBorder(
      borderRadius: BorderRadius.all(Radius.circular(50)),
      borderSide: BorderSide(
        color: Color.fromARGB(222, 63, 76, 160),
        width: 2.0,
        style: BorderStyle.solid,
      )
    );

     return const Padding(
       padding: EdgeInsets.all(8.0),
       child:  TextField(
          style:  TextStyle(color: Colors.white), 
          decoration: InputDecoration(
            hintText: "Please enter amount in rupee",
            hintStyle: TextStyle(color: Colors.white), 
            prefixIcon: Icon(
              Icons.monetization_on,
              color: Colors.white,
            ),
            filled: true,
            fillColor: Color.fromARGB(222, 63, 76, 160),
            focusedBorder: border,
            enabledBorder: border,
          ),
          keyboardType: TextInputType.numberWithOptions(decimal: true),
        ),
     );

  } 
}   