package com.example.assignment_task_lab13

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
